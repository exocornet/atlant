import './main.scss'

let tt = () => {
  return console.log('hello')
}

tt()
